package com.employee.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoEmployeeAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoEmployeeAppApplication.class, args);
	}

}
